package com.cg.dao;

import java.util.HashMap;

import com.cg.bean.Invoice;
//Declaring Methods
public interface InvoiceRepo {
//Method to add invoice into record
int saveInvoice(Invoice bean);
//Method to display records from collection
int displayCollection();
}
