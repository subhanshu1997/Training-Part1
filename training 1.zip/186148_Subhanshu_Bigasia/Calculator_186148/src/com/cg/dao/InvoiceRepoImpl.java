package com.cg.dao;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import com.cg.bean.Invoice;
//Implementing Methods
public class InvoiceRepoImpl implements InvoiceRepo{
//Declaring static collection HashMap
static HashMap<Integer,Invoice> hm=new HashMap<Integer,Invoice>();
//Implementing Method to add invoice into record
	@Override
	public int saveInvoice(Invoice bean) {
		int beforeSize=hm.size();
		//Inserting record into HashMap
		hm.put(bean.getId(),bean);
		int afterSize=hm.size();
		//Validating if record is inserted or not
		if(beforeSize+1==afterSize)
			return 1;
		return 0;
	}
//Implementing Method to display records from collection
	@Override
	public int displayCollection() {
		int size=hm.size();
		if(size>=1) {
		//Iterating through HashMap to print all records
		Set entrySet = hm.entrySet();
		Iterator it = entrySet.iterator();
		 while(it.hasNext()){
		       Map.Entry me = (Map.Entry)it.next();
		       System.out.println(hm.get(me.getKey()));
		   }
	}
		return size;
	}

}
