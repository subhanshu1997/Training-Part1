package com.cg.pl;

import java.util.Scanner;

import com.cg.bean.Invoice;
import com.cg.service.InvoiceService;
import com.cg.service.InvoiceServiceImpl;

public class Freight {

	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		while(true) {
		//Enabling user to choose a option
		System.out.println("Please enter your choice");
		System.out.println("1.Add Invoice");
		System.out.println("2.Display all Invoice");
		System.out.println("3.Exit");
		int choice=s.nextInt();
		//Generating InvoiceService Object
		InvoiceService is=new InvoiceServiceImpl();
		//Applying Swith Case
		switch(choice) {
		case 1:{
		//Accepting Weight from user
		System.out.println("Please enter Weight in KG");
		int weight=0;
		while(true) {
			//Validating Weight
			int input=s.nextInt();
			boolean ch=Validator.validateWeight(input);
			if(ch==true) {
				try {
				weight=input;
				break;
				}catch(Exception e) {
					System.out.println("Weight should be numeric");
				}
			}
			else {
				System.out.println("Please enter weight greater than or equal to 1KG");
			}
		}
		//Accepting Distance from user
		System.out.println("Please enter Distance in KM");
		int distance=0;
		while(true) {
			//Validating Distance
			int input=s.nextInt();
			boolean ch=Validator.validateDistance(input);
			if(ch==true) {
				try {
				distance=input;
				break;
				}catch(NumberFormatException e) {
					System.out.println("Distance should be numeric");
				}
			}
			else {
				System.out.println("Please enter distance greater than or equal to 100KM");
			}
		}
		Invoice invoice=new Invoice((int)(Math.random()*1000), weight, distance,0.0,0.0,0.0);
		if(is.calculateInvoice(invoice)==1) {
			System.out.println("Invoice Added");
		}
		else {
			System.out.println("Invoice not added");
		}
		break;
		}
		case 2:{
			//Displaying all entries from collection
			if(is.displayCollection()<1) {
				System.out.println("No records Exist");
			}
			break;
			
		}
		case 3:{
			//Exiting Program
			System.exit(0);
		}
		default:{
			//Checking if invalid choice is entered by user
			System.out.println("Please Enter Valid Choice");
		}
		}
		}
	}

}
