package com.cg.pl;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.Before;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.cg.bean.Invoice;
import com.cg.service.InvoiceService;
import com.cg.service.InvoiceServiceImpl;

class TestCases {
static Invoice in1=null;
static Invoice in2=null;
static InvoiceService is=new InvoiceServiceImpl();
	@BeforeAll
	//Initializing first object
	static void initialize1(){
		int id=(int)(Math.random()*1000);
		int weight=100;
		int distance=200;
		in1=new Invoice(id, weight, distance,0.0,0.0,0.0);
	}
	@BeforeAll
	//Initializing second object
	static void initialize2(){
		int id=(int)(Math.random()*1000);
		int weight=200;
		int distance=200;
		in2=new Invoice(id, weight, distance,0.0,0.0,0.0);
	}

	@Test
	//Insertion Test
	void testInsertion() {
		assertEquals(1,is.calculateInvoice(in1));
	}
	@Test
	//Printing Test
	void testPrinting() {
		is.calculateInvoice(in2);
		assertTrue(is.displayCollection()>=1);
	}
	


}
