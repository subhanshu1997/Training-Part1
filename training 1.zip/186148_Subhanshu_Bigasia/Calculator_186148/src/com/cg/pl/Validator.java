package com.cg.pl;

public class Validator {
	//Validating Weight
static boolean validateWeight(int weight) {
	//Return true if weight is greater than or equal to 1KG else return false
	if(weight<1) {
		return false;
	}
	return true;
}
//Validating Distance
static boolean validateDistance(int distance) {
	//Return true if distance is greater than or equal to 100KM else return false
	if(distance<100) {
		return false;
	}
	return true;
}
}
