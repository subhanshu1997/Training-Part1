package com.cg.service;

import java.util.HashMap;

import com.cg.bean.Invoice;

public interface InvoiceService {
int calculateInvoice(Invoice bean);
int displayCollection();
}
