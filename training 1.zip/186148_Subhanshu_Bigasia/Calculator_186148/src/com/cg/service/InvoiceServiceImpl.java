package com.cg.service;

import java.util.HashMap;

import com.cg.bean.Invoice;
import com.cg.dao.InvoiceRepo;
import com.cg.dao.InvoiceRepoImpl;

public class InvoiceServiceImpl implements InvoiceService{
InvoiceRepo invoiceRepo=new InvoiceRepoImpl();
	@Override
	public int calculateInvoice(Invoice bean) {
		double transportation=2*bean.getDistance()*bean.getWeight();
		double cgst=0.035*transportation;
		double sgst=0.035*transportation;
		bean.setAmount(transportation+cgst+sgst);
		bean.setCgst(cgst);
		bean.setSgst(sgst);
		if(invoiceRepo.saveInvoice(bean)==1)
			return 1;
		return 0;
	}

	@Override
	public int displayCollection() {
		return invoiceRepo.displayCollection();		
	}

}
