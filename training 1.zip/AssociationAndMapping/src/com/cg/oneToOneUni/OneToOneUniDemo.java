package com.cg.oneToOneUni;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class OneToOneUniDemo {
	public static void main(String[] args) {
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager em=emf.createEntityManager();
		Student s1=new Student();
		Address a1=new Address();
		a1.setCity("Pune");
		a1.setCountry("India");
		s1.setName("Subhanshu");
		s1.setRollno(50);
		s1.setAddress(a1);
		em.getTransaction().begin();
		em.persist(s1);
		em.getTransaction().commit();
		System.out.println("Student and address added");
	}
	
}
