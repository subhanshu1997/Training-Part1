package com.cg.controller;

import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.util.HashMap;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.bean.Course;
import com.cg.dao.TrainingDao;
import com.cg.dao.TrainingDaoImpl;
import com.cg.service.Service;
import com.cg.service.ServiceImpl;

/**
 * Servlet implementation class ShowTraining
 */
@WebServlet("/ShowTraining")
public class ShowTraining extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ShowTraining() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
    HttpServletResponse response;
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		if(request.getParameter("action").equals("index")){
			RequestDispatcher rd=request.getRequestDispatcher("Show.jsp");
//			this.response=response;
//			Service service=new ServiceImpl();
//			service.showTraining();
			rd.forward(request,response);
		}
//		else if(request.getParameter("action").equals("Show")){
//			TrainingDao td=new TrainingDaoImpl();
//			HashMap<Integer,Course> hm=td.showTraining();
////			System.out.println(hm);
////			PrintWriter out=this.response.getWriter();
//			for(Integer i:hm.keySet()){
//				System.out.println("Hello");
//				System.out.print(i+" ");
//				System.out.print(hm.get(i).getTrainingName()+" ");
//				System.out.print(hm.get(i).getAvailableSeats()+" ");
//				System.out.println();
//			}
//		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		if(request.getParameter("action").equals("Show")){
			Service service=new ServiceImpl();
			if(request.getParameter("button").equals("Spring")){
//				TrainingDao td=new TrainingDaoImpl();
				System.out.println("Spring");
				service.bookSeat(request.getParameter("button"));
//				TrainingDao td1=new TrainingDaoImpl();
//				HashMap<Integer,Course> hm=td1.showTraining();
////				System.out.println(hm);
////				PrintWriter out=this.response.getWriter();
//				for(Integer i:hm.keySet()){
//					System.out.println("Hello");
//					System.out.print(i+" ");
//					System.out.print(hm.get(i).getTrainingName()+" ");
//					System.out.print(hm.get(i).getAvailableSeats()+" ");
//					System.out.println();
//				}
			}
			else if(request.getParameter("button").equals("Hibernate")){
				System.out.println("Hibernate");
				TrainingDao td=new TrainingDaoImpl();
				td.bookSeat(request.getParameter("button"));
			}
			else if(request.getParameter("button").equals("EJB")){
				System.out.println("EJB");
				TrainingDao td=new TrainingDaoImpl();
				td.bookSeat(request.getParameter("button"));
			}
		}
	}

}
