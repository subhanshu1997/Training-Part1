package com.cg.service;

public interface Service {
	public void showTraining();
	public void bookSeat(String name);
}
