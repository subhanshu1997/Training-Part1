package com.cg.service;

import java.util.HashMap;

import com.cg.bean.Course;
import com.cg.dao.TrainingDao;
import com.cg.dao.TrainingDaoImpl;

public class ServiceImpl implements Service{
	public void showTraining(){
		TrainingDao td=new TrainingDaoImpl();
		HashMap<Integer,Course> hm=td.showTraining();
		System.out.println(hm);
	}

	@Override
	public void bookSeat(String name) {
		TrainingDao td=new TrainingDaoImpl();
		td.bookSeat(name);
		
	}
}
