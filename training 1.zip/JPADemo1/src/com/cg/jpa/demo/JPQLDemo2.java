package com.cg.jpa.demo;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import com.cg.jpa.entity.Account;

public class JPQLDemo2 {
	public static void main(String[] args) {
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager em=emf.createEntityManager();
//		Account ac1=new Account();
//		ac1.setAccHolderName("Nikhil");
//		ac1.setBalance(1000);
//		ac1.setMobileNo("91864857455");
//		Account ac2=new Account();
//		ac2.setAccHolderName("Ajay");
//		ac2.setBalance(5000);
//		ac2.setMobileNo("45464545454");
//		Account ac3=new Account();
//		ac3.setAccHolderName("Vishaka");
//		ac3.setBalance(90000);
//		ac3.setMobileNo("8978745445646");
//		Account ac4=new Account();
//		ac3.setAccHolderName("Subhanshu");
//		ac3.setBalance(1000000);
//		ac3.setMobileNo("7875497445646");
//		em.getTransaction().begin();
//		em.persist(ac1);
//		em.persist(ac2);
//		em.persist(ac3);
//		em.persist(ac4);
//		em.getTransaction().commit();
//		System.out.println("Account added");
		String qry="select acc.accHolderName from Account acc where acc.balance between :b1 and :b2";
//		TypedQuery<String> query=em.createQuery(qry,String.class);
		TypedQuery<String> query=em.createNamedQuery("getNames",String.class);
		query.setParameter("b1",1.00);
		query.setParameter("b2",90000.00);
		List<String> namelist=query.getResultList();
		for(String name:namelist) {
			System.out.println(name);
		}
	}
	

}
