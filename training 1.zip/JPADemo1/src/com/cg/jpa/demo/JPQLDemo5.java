package com.cg.jpa.demo;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import com.cg.jpa.entity.Account;

public class JPQLDemo5 {
	public static void main(String[] args) {
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager em=emf.createEntityManager();
//		Account ac1=new Account();
//		ac1.setAccHolderName("Nikhil");
//		ac1.setBalance(1000);
//		ac1.setMobileNo("91864857455");
//		Account ac2=new Account();
//		ac2.setAccHolderName("Ajay");
//		ac2.setBalance(5000);
//		ac2.setMobileNo("45464545454");
//		Account ac3=new Account();
//		ac3.setAccHolderName("Vishaka");
//		ac3.setBalance(90000);
//		ac3.setMobileNo("8978745445646");
//		Account ac4=new Account();
//		ac3.setAccHolderName("Subhanshu");
//		ac3.setBalance(1000000);
//		ac3.setMobileNo("7875497445646");
//		em.getTransaction().begin();
//		em.persist(ac1);
//		em.persist(ac2);
//		em.persist(ac3);
//		em.persist(ac4);
//		em.getTransaction().commit();
//		System.out.println("Account added");
		String qry="update Account acc set acc.balance=1.1*acc.balance";
		em.getTransaction().begin();
		Query query=em.createQuery(qry);
		int rows=query.executeUpdate();
		System.out.println(rows+"Updated  ");
		em.getTransaction().commit();
	}
	

}
