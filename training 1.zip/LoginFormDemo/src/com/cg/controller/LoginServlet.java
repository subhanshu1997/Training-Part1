package com.cg.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.bean.Login;
import com.cg.service.LoginService;
import com.cg.service.LoginServiceImpl;

/**
 * Servlet implementation class LoginServlet
 */
@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    LoginService service =
    		new LoginServiceImpl();
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LoginServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		String qStr = request.getParameter("action");
		if("index".equals(qStr))
		{
			RequestDispatcher dispatch = 
					request.getRequestDispatcher("login.html");
			dispatch.forward(request, response);
			
		}
		if("getData".equals(qStr))
		{
			ArrayList<Login> list = service.getAllDetails();
			PrintWriter out = response.getWriter();
			out.println("<html>");
			out.println("<body>");
			out.println("<table border='1'>");
			out.println("<caption>"+"User Details"+"</caption>");
			for(Login obj : list)
			{
				out.println("<tr>");
				out.println("<td>"+obj.getUsername()+"</td>");
				out.println("<td>"+obj.getPassword()+"</td>");
				out.println("<td>"+"<a href='LoginServlet?action=remove&user="+obj.getUsername()+"'>"+"Remove"+"</a>"+"</td>");
				out.println("</tr>");
			}
			out.println("</table>");
			out.println("</body>");
			out.println("</html>");
			
		}
		if("remove".equals(qStr))
		{
			String username = request.getParameter("user");
			PrintWriter out = response.getWriter();
			out.println("deleted username = "+username);
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		String qStr = request.getParameter("action");
		if("login".equals(qStr))
		{
			String user = request.getParameter("username");
			String password = request.getParameter("password");
			Login login = new Login(user,password);
			Login obj = service.loginUser(login);
			PrintWriter out = response.getWriter();
			if(obj!=null){
			
			out.println("Welcome");
			out.println("you are logged in with username "+user
					+" & password "+password);
			}
			else
			{
				out.print("Invalid");
			}
		}
		
	}

}
