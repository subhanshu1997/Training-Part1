package com.cg.dao;

import java.util.ArrayList;

import com.cg.bean.Login;

public interface LoginDao {

	public Login loginUser(Login user);
	ArrayList<Login>getAllDetails();
}
