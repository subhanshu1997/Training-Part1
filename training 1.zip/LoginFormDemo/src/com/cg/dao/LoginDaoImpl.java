package com.cg.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

import com.cg.bean.Login;
import com.cg.util.DBUtil;

public class LoginDaoImpl implements LoginDao{

	Connection con = DBUtil.getConnect();
	@Override
	public Login loginUser(Login user) {
		// TODO Auto-generated method stub
		Login obj = null;
		String qry = "SELECT * FROM UserDetails";
		try{
		Statement stmt = 
				con.createStatement();
		ResultSet rs = stmt.executeQuery(qry);
		while(rs.next())
		{
			String uName = rs.getString(1);
			String pWd = rs.getString(2);
			if(uName.equals(user.getUsername())&&pWd.equals(user.getPassword()))
			{
				obj = user;
				break;
			}
		}
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
		}
		return obj;
	}
	@Override
	public ArrayList<Login> getAllDetails() {
		// TODO Auto-generated method stub
		ArrayList<Login> list = 
				new ArrayList<Login>();
		String qStr = "SELECT * FROM UserDetails";
		try{
		Statement stmt = con.createStatement();
		ResultSet rs = stmt.executeQuery(qStr);
		while(rs.next())
		{
			Login login = new Login(rs.getString(1),rs.getString(2));
			list.add(login);
		}
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
		}
		return list;
	}
	
	

}
