package com.cg.service;

import java.util.ArrayList;

import com.cg.bean.Login;

public interface LoginService {
	
	public Login loginUser(Login user);
	ArrayList<Login>getAllDetails();

}
