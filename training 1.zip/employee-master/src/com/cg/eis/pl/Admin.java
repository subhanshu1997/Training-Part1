package com.cg.eis.pl;
import java.io.*;

import com.cg.eis.bean.Employee;
import com.cg.eis.service.Validator;
import com.cg.eis.service.*;

public class Admin {
public static void main(String[] args) throws IOException {
	while(true) {
	System.out.println("1. Add Employee");
	System.out.println("2. Delete Employee");
	System.out.println("3. Get Employee Details");
	System.out.println("4. Get All Employee Details");
	System.out.println("5. Get Insurance Scheme");
	System.out.println("6. exit");
	BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
	String choice=br.readLine();
	ServicesOffered so=new ServicesImplemented();
	switch(choice) {
	case "1":{
		int eid=0;
		String name="";
		double salary;
		String designation;
		String insurancescheme;
		//Getting input from user
		//Getting Employee ID
		System.out.println("Enter Employee Id");
		while(true) {
			//Validating Employee ID 
			String input=br.readLine();
			boolean ch=Validator.validate(input,Validator.eidpattern);
			if(ch==true) {
				try {
				eid=Integer.parseInt(input);
				break;
				}catch(NumberFormatException e) {
					System.out.println("Account number must be numeric");
				}
			}
			else {
				System.out.println("Enter valid Employee number");
			}
		}
		//Getting Employee Name
		System.out.println("Enter Employee Name");
		while(true) {
			//Validating Employee Name
			String input=br.readLine();
			boolean ch=Validator.validate(input,Validator.namepattern);
			if(ch==true) {
				name=input;
				break;
			}
			else {
				System.out.println("Enter valid Employee Name");
			}
		}
		//Getting Employee Designation
		System.out.println("Enter Employee Designation");
		while(true) {
			//Validating Employee Designation 
			String input=br.readLine();
			boolean ch=Validator.validate(input,Validator.namepattern);
			if(ch==true) {
				designation=input;
				break;
			}
			else {
				System.out.println("Enter valid Employee Designation");
			}
		}
		//Getting Employee Salary
		System.out.println("Enter Employee Salary");
		while(true) {
			//Validating Employee Salary
		String input=br.readLine();
		boolean ch=Validator.validate(input,Validator.salary);
		if(ch==true) {
			salary=Double.parseDouble(input);
			break;
		}
		else {
			System.out.println("Enter Valid Salary");
		}
		}
//		System.out.println("Enter Employee InsuranceScheme");
//		input=br.readLine();
//		while(true) {
//			boolean ch=Validator.validate(input,Validator.namepattern);
//			if(ch==true) {
//				insurancescheme=input;
//				break;
//			}
//			else {
//				System.out.println("Enter valid Employee Designation");
//			}
//		}
		//Creating Employee Object
		Employee e=new Employee(eid, name, salary, designation,null);
		//Adding Employee 
		so.addEmployee(e);
//		Employee e=new Employee(id, name, salary, designation, InsuranceScheme)
	}break;
	case "2":{
		int eid;
		//Getting Employee ID
		System.out.println("Enter Employee Id");
		while(true) {
			//Validating Employee ID 
			String input=br.readLine();
			boolean ch=Validator.validate(input,Validator.eidpattern);
			if(ch==true) {
				try {
				eid=Integer.parseInt(input);
				break;
				}catch(NumberFormatException e) {
					System.out.println("Account number must be numeric");
				}
			}
			else {
				System.out.println("Enter valid Employee number");
			}
		}
		//Deleting Employee
		if(so.deleteEmployee(eid)==false) {
			System.out.println("Employee does not exist");
		}
	}break;
	case "3":{
		int eid;
		//Getting Employee ID
		System.out.println("Enter Employee Id");
		while(true) {
			//Validating Employee ID 
			String input=br.readLine();
			boolean ch=Validator.validate(input,Validator.eidpattern);
			if(ch==true) {
				try {
				eid=Integer.parseInt(input);
				break;
				}catch(NumberFormatException e) {
					System.out.println("Account number must be numeric");
				}
			}
			else {
				System.out.println("Enter valid Employee number");
			}
		}
		//Getting Employee Details
		so.getDetails(eid);	
	}break;
	case "4":{
		//Getting All Employee Details
		so.getAllEmployeeDetails();
	
	}break;
	case "5":{
		double salary;
		String designation;
		//Getting Employee Designation
		System.out.println("Enter Employee Designation");
		while(true) {
			//Validating Employee Designation
			String input=br.readLine();
			boolean ch=Validator.validate(input,Validator.namepattern);
			if(ch==true) {
				designation=input;
				break;
			}
			else {
				System.out.println("Enter valid Employee Designation");
			}
		}
		//Getting Employee Salary
		System.out.println("Enter Employee Salary");
		while(true) {
			//Validating Employee Salary
		String input=br.readLine();
		boolean ch=Validator.validate(input,Validator.salary);
		if(ch==true) {
			salary=Double.parseDouble(input);
			break;
		}
		else {
			System.out.println("Enter Valid Salary");
		}
		}
		//Getting Insurance Scheme
		System.out.println(so.getInsuranceScheme(salary,designation));	
	}break;
	case "6":{
		//Exiting Program
		System.out.println("Exiting Program");
		System.exit(0);
	}break;
	}
	}
}
}
